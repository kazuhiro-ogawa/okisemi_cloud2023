package com.example.azurehttprequest;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.os.HandlerCompat;

import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.TimeZone;
import java.util.concurrent.Executors;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;


public class MainActivity extends AppCompatActivity {

    private LineChart mChart;
    private final Handler handler = new Handler();

    private final Runnable updateDataRunnable = new Runnable(){
        @Override
        public void run() {
            fetchDataAndDrawChart(); // グラフデータの取得と描画のメソッド
            handler.postDelayed(this, 60000); // 1分後に再実行
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        handler.post(updateDataRunnable); // Runnableの実行を開始
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(updateDataRunnable); // アクティビティが破壊されるときにRunnableの実行を停止
    }

    private void setData(ArrayList<Entry> tempEntryList, ArrayList<Entry> humiEntryList) {
        LineDataSet set1;
        LineDataSet set2;

        if (mChart.getData() != null &&
                mChart.getData().getDataSetCount() > 0) {

            set1 = (LineDataSet) mChart.getData().getDataSetByIndex(0);
            set1.setValues(tempEntryList);
            set2 = (LineDataSet) mChart.getData().getDataSetByIndex(1);
            set2.setValues(humiEntryList);
            mChart.getData().notifyDataChanged();
            mChart.notifyDataSetChanged();
        } else {
            // create a dataset and give it a type
            set1 = new LineDataSet(tempEntryList, "温度");
            set1.setAxisDependency(YAxis.AxisDependency.LEFT);
            set1.setValues(tempEntryList);
            set2 = new LineDataSet(humiEntryList, "湿度");
            set2.setAxisDependency(YAxis.AxisDependency.RIGHT);
            set2.setValues(humiEntryList);

            set1.setDrawIcons(false);
            set1.setColor(Color.BLACK);
            set1.setCircleColor(Color.BLACK);
            set1.setLineWidth(1f);
            set1.setCircleRadius(3f);
            set1.setDrawCircleHole(false);
            set1.setValueTextSize(0f);
            set1.setDrawFilled(true);
            set1.setFormLineWidth(1f);
            set1.setFormLineDashEffect(new DashPathEffect(new float[]{10f, 5f}, 0f));
            set1.setFormSize(15.f);
            set1.setFillColor(Color.BLUE);

            set2.setDrawIcons(false);
            set2.setColor(Color.RED);
            set2.setCircleColor(Color.RED);
            set2.setLineWidth(1f);
            set2.setCircleRadius(3f);
            set2.setDrawCircleHole(false);
            set2.setValueTextSize(0f);
            set2.setDrawFilled(true);
            set2.setFormLineWidth(1f);
            set2.setFormLineDashEffect(new DashPathEffect(new float[]{10f, 5f}, 0f));
            set2.setFormSize(15.f);
            set2.setFillColor(Color.YELLOW);

            ArrayList<ILineDataSet> dataSets = new ArrayList<>();
            dataSets.add(set1); // add the datasets
            dataSets.add(set2); // add the datasets

            // create a data object with the datasets
            LineData lineData = new LineData(dataSets);

            // set data
            mChart.setData(lineData);
        }
    }

    private void fetchDataAndDrawChart() {
        Executors.newSingleThreadExecutor().execute(() ->{
            try{
                URL url = new URL("https://okisemi2023-02read.azurewebsites.net/api/GetTHData?code=9fyw6eRBM2i-64M3hxp0lPJWOjxYavg01LMHTnQyNKlhAzFu6OpoHQ==");
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("GET");
                BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream(), StandardCharsets.UTF_8));
                StringBuilder builder = new StringBuilder();
                String line;
                while((line = reader.readLine()) != null
                ){
                    builder.append(line);
                }
                //Log.d("receiveData", builder.toString());
                HandlerCompat.createAsync(getMainLooper()).post(() ->
                {
                    mChart = findViewById(R.id.line_chart);

                    // Grid背景色
                    mChart.setDrawGridBackground(true);

                    // no description text
                    mChart.getDescription().setEnabled(true);

                    // Grid縦軸を破線
                    XAxis xAxis = mChart.getXAxis();
                    xAxis.enableGridDashedLine(10f, 10f, 0f);
                    xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
                    xAxis.setLabelCount(10);

                    YAxis leftAxis = mChart.getAxisLeft();
                    YAxis rightAxis = mChart.getAxisRight();

                    // 左Y軸最大最小設定
                    leftAxis.setAxisMaximum(40f);
                    leftAxis.setAxisMinimum(0f);

                    // 右Y軸最大最小設定
                    rightAxis.setAxisMaximum(100f);
                    rightAxis.setAxisMinimum(0);

                    // Grid横軸を破線
                    leftAxis.enableGridDashedLine(10f, 10f, 0f);
                    leftAxis.setDrawZeroLine(true);

                    // Grid横軸を破線
                    rightAxis.enableGridDashedLine(10f, 10f, 0f);
                    rightAxis.setDrawZeroLine(true);

                    ArrayList<Entry> tempList = new ArrayList<>();
                    ArrayList<Entry> humiList = new ArrayList<>();

                    String[] labels = new String[10];

                    try{
                        JSONArray jsonArray = new JSONArray(builder.toString());
                        Log.d("receiveData", String.valueOf(jsonArray.length()));
                        int index = 0;
                        for(int i = jsonArray.length() - 10; i < jsonArray.length(); i++){
                            JSONObject jsonObject = jsonArray.getJSONObject(i);

                            String time_str = jsonObject.getString("time");
                            Log.d("receiveData", "Timestamp from JSON: " + time_str); // Add this line to debug

                            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'z'");
                            Date date = null;
                            try {
                                date = formatter.parse(time_str);
                                Log.d("receiveData", "Parsed Date: " + date); // Add this line to debug
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }

                            SimpleDateFormat outputFormat = new SimpleDateFormat("HH:mm:ss");
                            String output = outputFormat.format(date);
                            Log.d("receiveData", output);
                            labels[index] = output;

                            double temp_d = jsonObject.getDouble("temp");
                            float temp_f = (float)temp_d;

                            double humi_d = jsonObject.getDouble("humi");
                            float humi_f = (float)humi_d;
                            Log.d("receiveData", String.valueOf(humi_f));

                            tempList.add(new Entry( index , temp_f, null, null));
                            humiList.add(new Entry( index , humi_f, null, null));
                            index++;
                        }

                    }catch (JSONException e){
                        e.printStackTrace();
                    }

                    xAxis.setValueFormatter(new ValueFormatter() {
                        @Override
                        public String getFormattedValue(float value){
                            Log.d("receiveData2", labels[(int) value]);
                            return labels[(int) value];
                        }
                    });

                    // add data
                    setData(tempList, humiList);

                    mChart.animateX(2500);
                    //mChart.invalidate();

                    // dont forget to refresh the drawing
                    // mChart.invalidate();

                });
            }catch(Exception e){
                e.printStackTrace();
            }
        });
    }
}